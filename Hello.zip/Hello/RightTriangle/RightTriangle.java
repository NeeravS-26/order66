public class RightTriangle
{
    public static void main(String[] args)
    {
        double a = Double.parseDouble(args[0]);
        double b = Double.parseDouble(args[1]);
        double c = Double.parseDouble(args[2]);
        boolean isPositive = (a > 0 && b > 0 && c > 0);
        boolean isRight = (a * a + b * b == c * c) || (a * a + c * c == b * b) || (b * b + c * c == a * a);
        System.out.println(isPositive && isRight);
    }
}
