public class GeneralizedHarmonic
{
    public static void main(String[] args)
    {
        // Take input values from cmd-line
        int n = Integer.parseInt(args[0]); // n = number of terms
        int r = Integer.parseInt(args[1]); // r = power

        // Initialize sum (we use double because result is decimal)
        double sum = 0.0;

        // Run loop from i = 1 to i = n (inclusive)
        for (int i = 1; i <= n; i++)
        {
            // For each term, add 1 / (i^r) to sum
            sum += 1.0 / Math.pow(i, r);
        }

        // Print final answer
        System.out.println(sum);
    }
}
