public class BandMatrix
{
    public static void main(String[] args)
    {
        int n     = Integer.parseInt(args[0]); // Matrix size
        int width = Integer.parseInt(args[1]); // Width from main diagonal

        // each row (loop)
        for (int i = 0; i < n; i++)
        {
            // each column (loop2)
            for (int j = 0; j < n; j++)
            {
                // check distance of the element from the diagonal
                if (Math.abs(i - j) <= width)
                {
                    System.out.print("*  "); // Inside band
                }
                else
                {
                    System.out.print("0  "); // Outside band
                }
            }
            System.out.println();
        }
    }
}
